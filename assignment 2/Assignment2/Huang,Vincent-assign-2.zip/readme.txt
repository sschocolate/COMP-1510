[Vincent Huang], [A00894773], [C], [March 01, 2014]

This assignment is 100% complete.


------------------------
Question one (TriangleArea) status:

Complete

------------------------
Question two (CylinderStats) status:

Complete

------------------------
Question three (Bookshelf) status:

Complete

------------------------
Question four (BoxTest) status:

Complete

------------------------
Question five (TrafficLight) status:

Complete